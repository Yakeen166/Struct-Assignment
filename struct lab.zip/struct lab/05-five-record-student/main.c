#include <stdio.h>

struct data{
    int id;
    char name[20];
    char address[20];
    char faculty[20];

    struct date{
        int year,month,day;
    }date;
};


int main()
{
    struct data user[4]={
    {
        .id=1,
        .name="ahghchc",
        .address="b",
        .faculty="c",
                .date={2000,1,2},
     },
    {},
    {},
    };

//    struct date user[3]={

//    };



    for(int i=0; i<2; i++){
        printf("id");
        scanf("%d",&user[i].id);

        printf("name");
        gets(&user[i].name);

        printf("address");
        gets(&user[i].address);

        printf("faculty");
        gets(&user[i].faculty);

        printf("year");
        scanf("%d",&user[i].date.year);

        printf("month");
        scanf("%d",&user[i].date.month);

        printf("day");
        scanf("%d",&user[i].date.day);
    }

    printf("id \tname \tadd \tfavculty \n");

    for(int i=0; i<2; i++){
        printf("%d \t%s \t%s \t%s \n",user[i].id,user[i].name,user[i].address,user[i].faculty);
        printf("%d %d %d",user[i].date.year,user[i].date.month,user[i].date.day);
    }





    return 0;
}
