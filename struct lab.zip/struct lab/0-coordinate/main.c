#include <stdio.h>

struct coordinate{
    int x,y;
};

int main()
{
    struct coordinate point;

    printf("Enter x:");
    scanf("%d",&point.x);
    printf("Enter y:");
    scanf("%d",&point.y);

    printf("The coordinate is (%d,%d).\n",point.x,point.y);
    return 0;
}
