#include <stdio.h>
struct coordinate{
    int x,y;
};
 struct points{
    struct coordinate p1,p2,p3;

};

int main()
{
    struct points t={{0,0},{100,75},{-60,80}};
    printf("The endpoints of given triangle are (%d,%d),(%d,%d),(%d,%d).\n ",t.p1.x,t.p1.y,t.p2.x,t.p2.y,t.p3.x,t.p3.y);
    return 0;
}
