#include <stdio.h>
struct date{
    int year,month,day,id;
};
struct data{
    char name[20];
    char address[20];
    char faculty[20];

};

int main()
{
//    struct data user[3]={
//    {
//                .name="y",
//                .address="www",
//                .faculty="qqq",
//    },
//    {},
//    {},

//};

    struct data user={
    {"Suraz Pahari"},{"Sedi-13,Pokhara"},{"Software"}

};
    struct date user1={2000,1,2,1};

    printf("%.2d) Name : %s \tFaculty:%s\n    Address: %s \tD.O.B : (%d,%.2d,%.2d)\n    ",user1.id,user.name,user.faculty,user.address,user1.year,user1.month,user1.day);

    return 0;
}
