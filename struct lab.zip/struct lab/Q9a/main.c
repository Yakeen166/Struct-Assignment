#include <stdio.h>
#define N 4

struct student{
    char name[20];
    int eng;
    int math;
    int phys;
    float average;
};

static struct student data[]={
    {"Ram", 82, 72, 98},
    {"Hari", 77, 82, 99},
    {"Ashesh", 52, 62, 99},
    {"Aayush", 61, 82, 98}
};

char gradeCheck(int average){
    if(average >= 90){
        return 'S';
    }else if(average >= 80){
        return 'A';
    }else if(average >= 70){
        return 'B';
    }else if(average >= 60){
        return 'C';
    }else{
        return 'D';
    }
}

float averageCalc(float mark1, float mark2, float mark3, float mark4){
    float average = (double)(mark1+mark2+mark3+mark4)/4;
    return average;
}

int main(void)
{
    int i;
    for(i=0; i<N; i++){
        float average = (double)(data[i].eng+data[i].math+data[i].phys)/3;
        printf("%7s: Eng = %3d Math = %3d Phys = %3d Average = %3f Grade = %c\n", data[i].name, data[i].eng, data[i].math, data[i].phys, average, gradeCheck(average));
    }

    float averagePhys = averageCalc(data[0].phys,data[1].phys,data[2].phys,data[3].phys);
    float averageMath = averageCalc(data[0].math,data[1].math,data[2].math,data[3].math);
    float averageEng = averageCalc(data[0].eng,data[1].eng,data[2].eng,data[3].eng);

    if(averagePhys < averageMath && averagePhys < averageEng){
        printf("Students are weak in Physics\n");
    }else if(averageMath < averagePhys && averageMath < averageEng){
        printf("Students are weak in Math\n");
    }else if(averageEng < averageMath && averageEng < averagePhys){
        printf("Students are weak in English\n");
    }

    return (0);
}
