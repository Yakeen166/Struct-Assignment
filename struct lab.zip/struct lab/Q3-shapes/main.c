#include <stdio.h>
struct coordinate{
    int x,y;
};

struct points{
    struct coordinate p1,p2,p3,p4;
};

struct radius{
    struct coordinate r1,r2;
};

int main()
{
    struct points rec={{1,2},{3,4},{4,5},{6,7}};
    struct points sq={{1,2},{3,4},{4,5},{6,7}};
    struct radius c={{8,9},{0,3}};

    printf("The end points of rectangle are [%d,%d],[%d,%d],[%d,%d],[%d,%d].\n",rec.p1.x,rec.p1.y,rec.p2.x,rec.p2.y,rec.p3.x,rec.p3.y,rec.p4.x,rec.p4.y);
    printf("The points radius of circle is [%d,%d] and [%d,%d].\n",c.r1.x,c.r1.y,c.r2.x,c.r2.y);
    return 0;
}
